# __init__.py

from .chatbot import VoiAssistant

# Make VoiAssistant accessible when importing the package
__all__ = ['VoiAssistant']

